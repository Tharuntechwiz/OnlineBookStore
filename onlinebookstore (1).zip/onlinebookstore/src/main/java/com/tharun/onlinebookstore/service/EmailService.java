package com.tharun.onlinebookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.tharun.onlinebookstore.entity.Customer;

@Service
public class EmailService {
	@Autowired
	private JavaMailSender javaMailSender;
    
	public void sendMail(String findByEmail, String subject, String body) {
		System.out.println(findByEmail); 
		System.out.println(subject); 
		System.out.println(body); 
		SimpleMailMessage s = new SimpleMailMessage();
		s.setTo(findByEmail);
		s.setSubject(subject);
		s.setText(body);
		javaMailSender.send(s);

	}
}