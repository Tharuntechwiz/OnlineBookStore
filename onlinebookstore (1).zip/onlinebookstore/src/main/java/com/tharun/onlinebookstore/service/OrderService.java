package com.tharun.onlinebookstore.service;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.tharun.onlinebookstore.entity.Book;
import com.tharun.onlinebookstore.entity.Customer;
import com.tharun.onlinebookstore.entity.Order;
import com.tharun.onlinebookstore.entity.OrderItem;
import com.tharun.onlinebookstore.entity.OrderStatus;
import com.tharun.onlinebookstore.repository.BookRepo;
import com.tharun.onlinebookstore.repository.CustomerRepo;
import com.tharun.onlinebookstore.repository.OrderRepo;

@Service
public class OrderService {

    private final OrderRepo orderRepo;
    private final CustomerRepo customerRepo;
    private final BookRepo bookRepo;
    private final EmailService emailService;

    public OrderService(OrderRepo orderRepo, CustomerRepo customerRepo, BookRepo bookRepo, EmailService emailService) {
        this.orderRepo = orderRepo;
        this.customerRepo = customerRepo;
        this.bookRepo = bookRepo;
        this.emailService = emailService;
    }

    public Order placeOrder(Order order) {
        Customer customer = customerRepo.findById(order.getCustomer().getId())
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        BigDecimal total = BigDecimal.ZERO;
        for (OrderItem item : order.getItems()) {
            Book book = bookRepo.findById(item.getBook().getId())
                    .orElseThrow(() -> new RuntimeException("Book not found"));

            if (book.getStock() < item.getQuantity()) {
                throw new RuntimeException("Not enough stock for book: " + book.getTitle());
            }

            book.setStock(book.getStock() - item.getQuantity());
            bookRepo.save(book);

            BigDecimal itemTotal = book.getPrice().multiply(BigDecimal.valueOf(item.getQuantity()));
            item.setPrice(itemTotal);
            item.setOrder(order);

            // Set book details to ensure full object in response
            item.setBook(book);

            total = total.add(itemTotal);
        }

        BigDecimal discountRate = switch (customer.getMembershipLevel()) {
            case PREMIUM -> BigDecimal.valueOf(0.05);
            case GOLD -> BigDecimal.valueOf(0.10);
            default -> BigDecimal.ZERO;
        };

        BigDecimal discountAmount = total.multiply(discountRate);
        BigDecimal discountedTotal = total.subtract(discountAmount);

        BigDecimal shippingFee = BigDecimal.valueOf(20.00);
        if (discountedTotal.compareTo(BigDecimal.valueOf(100)) > 0) {
            shippingFee = BigDecimal.ZERO;
        }

        order.setCustomer(customer);
        order.setTotalPrice(discountedTotal.add(shippingFee));
        order.setShippingFee(shippingFee);
        order.setDiscountsApplied("Membership: " + customer.getMembershipLevel());
        order.setOrderStatus(OrderStatus.PLACED);

        Order savedOrder = orderRepo.save(order);
        
        Customer customer2 = new Customer();
        	Optional<Customer> findById = customerRepo.findById(customer.getId());
        System.out.println("email service");
        Customer findByID;
		
        emailService.sendMail(customer.getEmail(), "Online book store","order successfully conformed....."+customer.getName());

        return savedOrder;
    }
}
