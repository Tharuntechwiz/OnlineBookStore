package com.tharun.onlinebookstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tharun.onlinebookstore.entity.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Long> {
	
	Customer findByEmail(String email);
}
