package com.tharun.onlinebookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tharun.onlinebookstore.entity.Book;
import com.tharun.onlinebookstore.repository.BookRepo;

@Service
public class OnlineBookStoreService {
	
	@Autowired
    private final BookRepo bookRepo;

    public OnlineBookStoreService(BookRepo bookRepo) {
        this.bookRepo = bookRepo;
    }

    public Book saveBook(Book b) {
        return bookRepo.save(b); 
    }
    
}

