package com.tharun.onlinebookstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tharun.onlinebookstore.entity.Book;
import com.tharun.onlinebookstore.entity.Customer;
import com.tharun.onlinebookstore.service.OnlineBookStoreService;
import com.tharun.onlinebookstore.service.OnlineCustomerService;

@RestController
@RequestMapping("/onlinebookstore")
public class OnlineBookStoreController {

	@Autowired
	public OnlineBookStoreService bookStoreService;
	
	@Autowired
	public OnlineCustomerService customerService;

	@PostMapping("book/save")
	public ResponseEntity<Book> saveBook(@RequestBody Book b) {
		Book savedBook = bookStoreService.saveBook(b);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedBook);
	}

	@PostMapping("customer/save")
	public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
		Customer created = customerService.createCustomer(customer);
		return ResponseEntity.status(HttpStatus.CREATED).body(created);
	}
}
