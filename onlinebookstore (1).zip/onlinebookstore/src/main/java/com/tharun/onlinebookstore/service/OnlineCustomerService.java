package com.tharun.onlinebookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tharun.onlinebookstore.entity.Customer;
import com.tharun.onlinebookstore.repository.CustomerRepo;

@Service
public class OnlineCustomerService {
	
	 @Autowired
	  private CustomerRepo repository;
	 public Customer createCustomer(Customer customer) {
	        return repository.save(customer);
	    }
}
