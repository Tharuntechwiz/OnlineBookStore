package com.tharun.onlinebookstore.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.EnumType;

import java.time.LocalDate;

@Entity
public class Customer {

    @Id
    private Long id;  

    private String name;

    private String email;

    @Enumerated(EnumType.STRING)
    private MembershipLevel membershipLevel;

    private LocalDate registrationDate;

    public Customer() {}

    public Customer(String name, String email, MembershipLevel membershipLevel, LocalDate registrationDate) {
        this.name = name;
        this.email = email;
        this.membershipLevel = membershipLevel;
        this.registrationDate = registrationDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public MembershipLevel getMembershipLevel() {
        return membershipLevel;
    }

    public void setMembershipLevel(MembershipLevel membershipLevel) {
        this.membershipLevel = membershipLevel;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(LocalDate registrationDate) {
        this.registrationDate = registrationDate;
    }

    public enum MembershipLevel {
        STANDARD,
        PREMIUM,
        GOLD
    }
}

