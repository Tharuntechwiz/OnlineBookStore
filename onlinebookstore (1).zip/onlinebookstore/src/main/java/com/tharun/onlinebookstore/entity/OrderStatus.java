package com.tharun.onlinebookstore.entity;

public enum OrderStatus {
	PLACED, PROCESSING, SHIPPED, CANCELLED
}
